# Automta-Theory
A program to remove epsilon productions from a Context Free Grammar (CFG)


####program is in src/com/company

The program takes input from "cfg.txt" and produces "newCFG.txt" as output.
